<!DOCTYPE html>
<html lang="en">
<head>
    
    <title> 18MIS7073</title>
    <style>
        body{
            height:100vh;
            width:100vw;
            background:linear-gradient(107.99deg, #19fe8b 0.51%, rgba(217, 231, 17, 0.96) 100.48%);
            display:flex;
            justify-content:center;
            align-items:center;
            overflow:hidden;
            background-repeat:no-repeat;
            color:#fff;
        }
    </style>
</head>
<body>
    <h1>VALIDATION SUCCESSFUL</h1>
</body>
</html>